# Steps

Steps are used in scenarios. They do not keep any logic, but responsible for formatting. Exception for `ConditionalAssertion` which acts like `Assertion` but acts differently on fail.
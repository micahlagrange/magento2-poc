<?php
namespace Codeception\Exception;

class TestRuntimeException extends \RuntimeException
{
}

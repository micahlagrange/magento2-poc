<?php
namespace Codeception\Lib\Interfaces;

interface ORM
{
}

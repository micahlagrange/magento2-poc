<?php

namespace Vault\Exceptions;

/**
 * Class DependencyException
 *
 * @package Vault\Exception
 */
class DependencyException extends \RuntimeException
{
}